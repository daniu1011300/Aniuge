#include "adc_algorithm.h"

/*
 * 采样校准参数
 */
                                       /* VOLTAGE_LOW 0   CURRENT_HIGH 1  CURRENT_LOW 2   VOLTAGE_HIGH 3 */
const double value_key_sample[4][2] = { {5.057,  12.248}, {0.304, 0.727}, {0.606, 2.123}, {4.980, 24.02} };
                                       /* VOLTAGE_LOW 0   CURRENT_HIGH 1  CURRENT_LOW 2   VOLTAGE_HIGH 3 */
const uint16_t adc_key_sample[4][2] = { {  653,    1600}, {  131,    217}, {   154,    355}, {  612,   3119} };

uint8_t FIX_ZERO_POINT_FLAG = 0;




/*
 * ADC去极值平均滤波器
*/
uint16_t No_Max_Min_Filter(uint16_t *in_dat, uint16_t num, uint8_t channel_num, uint8_t n)
{
    int i;
    uint32_t sum = 0;
    float sum_f;
    uint16_t max_value, min_value;
    max_value = in_dat[n];
    min_value = in_dat[n];

    for(i=n; i<num*channel_num; i+=channel_num){
        if(in_dat[i] > max_value){
            max_value = in_dat[i];
        }
        if(in_dat[i] < min_value){
            min_value = in_dat[i];
        }
        sum += in_dat[i];
    }
    sum -= max_value;
    sum -= min_value;
    sum_f = (float)sum / (num - 2.0);
    return (uint16_t)sum_f;
}

/*
 * ADC值与电压电流值转化
*/
uint16_t Get_ADC_By_Value(double value, uint8_t type)
{
    double v1, v2;
    uint16_t d1, d2;

    v1 = value_key_sample[type][0];
    d1 = adc_key_sample[type][0];
    v2 = value_key_sample[type][1];
    d2 = adc_key_sample[type][1];

    return (value - ret_B)/ret_K;
}

double Get_Value_By_ADC(uint16_t adc, uint8_t type)
{
    double v1, v2;
    uint16_t d1, d2;
    v1 = value_key_sample[type][0];
    d1 = adc_key_sample[type][0];
    v2 = value_key_sample[type][1];
    d2 = adc_key_sample[type][1];
    return ret_K * adc + ret_B;
}

//double ACS712_Get_Value_By_ADC(uint16_t adc, uint8_t type)
//{
//    int16_t sum;
//    extern __IO uint16_t ADC_Current;
//    extern __IO uint16_t ADC_Current_Low; 
//    static uint16_t zero = 2017;
//    if(FIX_ZERO_POINT_FLAG) {
//        FIX_ZERO_POINT_FLAG = 0;
//        zero = (ADC_Current+ADC_Current_Low)/2;
//    }
//    sum = adc-zero;
//    return sum*12.4;
//}
