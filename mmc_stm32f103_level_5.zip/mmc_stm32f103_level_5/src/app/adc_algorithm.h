#ifndef __ADC_ALGORITHM_H
#define __ADC_ALGORITHM_H

#include <stdint.h>
#define ret_K ((v1-v2)/(d1-d2))
#define ret_B ((d1*v2-v1*d2)/(d1-d2))



uint16_t No_Max_Min_Filter(uint16_t *in_dat, uint16_t num, uint8_t channel_num, uint8_t type);
uint16_t Get_ADC_By_Value(double value, uint8_t type);
double Get_Value_By_ADC(uint16_t adc, uint8_t type);


#endif
