#ifndef __LCD_H
#define __LCD_H

//#include "sys.h"
#include "stm32f10x.h"

#define USE_HORIZONTAL 0  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 240
#define LCD_H 320

#else
#define LCD_W 320
#define LCD_H 240
#endif

//-----------------LCD�˿ڶ���---------------- 
//#define LCD_SPI_GPIOX                   (GPIOF)
//#define LCD_SPI_RCC_AHB1Periph_GPIOX    (RCC_AHB2Periph_GPIOF)
//#define LCD_SPI_CLK_PIN                 (GPIO_Pin_11)
//#define LCD_SPI_MOSI_PIN                (GPIO_Pin_12)
//#define LCD_SPI_RES_PIN                 (GPIO_Pin_13)
//#define LCD_SPI_DC_PIN                  (GPIO_Pin_14)
//#define LCD_SPI_MISO_PIN                (GPIO_Pin_15)

#define LCD_SPI_GPIOX                   (GPIOF)
#define LCD_SPI_RCC_AHB1Periph_GPIOX    (RCC_AHB2Periph_GPIOF)
#define LCD_SPI_CLK_PIN                 (GPIO_Pin_10)
#define LCD_SPI_MOSI_PIN                (GPIO_Pin_8)
#define LCD_SPI_RES_PIN                 (GPIO_Pin_13)
#define LCD_SPI_DC_PIN                  (GPIO_Pin_14)
#define LCD_SPI_MISO_PIN                (GPIO_Pin_15)

//-----------------LCD�˿ڶ���---------------- 
#define LCD_SCLK_Clr() GPIO_ResetBits(GPIOD,LCD_SPI_CLK_PIN)//SCL=SCLK
#define LCD_SCLK_Set() GPIO_SetBits(GPIOD,LCD_SPI_CLK_PIN)

#define LCD_MOSI_Clr() GPIO_ResetBits(GPIOD,LCD_SPI_MOSI_PIN)//SDA=MOSI
#define LCD_MOSI_Set() GPIO_SetBits(GPIOD,LCD_SPI_MOSI_PIN)

#define LCD_RES_Clr()  GPIO_ResetBits(LCD_SPI_GPIOX,LCD_SPI_RES_PIN)//RES
#define LCD_RES_Set()  GPIO_SetBits(LCD_SPI_GPIOX,LCD_SPI_RES_PIN)

#define LCD_DC_Clr()   GPIO_ResetBits(LCD_SPI_GPIOX,LCD_SPI_DC_PIN)//DC
#define LCD_DC_Set()   GPIO_SetBits(LCD_SPI_GPIOX,LCD_SPI_DC_PIN)
 		     
#define LCD_CS_Clr()   GPIO_ResetBits(LCD_SPI_GPIOX,LCD_SPI_MISO_PIN)//CS
#define LCD_CS_Set()   GPIO_SetBits(LCD_SPI_GPIOX,LCD_SPI_MISO_PIN)

#define LCD_BLK_Clr()  GPIO_ResetBits(LCD_SPI_GPIOX,GPIO_Pin_6)//BLK
#define LCD_BLK_Set()  GPIO_SetBits(LCD_SPI_GPIOX,GPIO_Pin_6)


void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




