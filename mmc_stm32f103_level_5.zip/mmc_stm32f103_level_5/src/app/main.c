/* Proj 2019 */
/* By hxdyxd */


#include "soft_timer.h"
#include "app_debug.h"
#include "type.h"

//hal
#include "data_interface_hal.h"
#include "adc_algorithm.h"

/**********Aniuge 20200519*************************/
#include "lcd.h"
#include "LCD_APP.h"

float ADC_Test[8];
uint8_t KEY=0;

void led_proc(void)
{
    led_rev(LED_0);
}

void MMC_Voltage(void)
{
	char buf[20];
	float test;
	
	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM1  %7.2fV", ADC_Test[0]);
	LCD_ShowString(0,0,(uint8_t*)buf,RED,WHITE,32,0);

	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM2  %7.2fV", ADC_Test[1]);
	LCD_ShowString(0,30,(uint8_t*)buf,RED,WHITE,32,0);
	
	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM3  %7.2fV", ADC_Test[2]);
	LCD_ShowString(0,60,(uint8_t*)buf,RED,WHITE,32,0);

	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM4  %7.2fV", ADC_Test[3]);	
	LCD_ShowString(0,90,(uint8_t*)buf,RED,WHITE,32,0);
	
	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM5  %7.2fV", ADC_Test[5]);
	LCD_ShowString(0,120,(uint8_t*)buf,RED,WHITE,32,0);
	
	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM6  %7.2fV",	ADC_Test[0]);
	LCD_ShowString(0,150,(uint8_t*)buf,RED,WHITE,32,0);

	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM7  %7.2fV", ADC_Test[1]);
	LCD_ShowString(0,180,(uint8_t*)buf,RED,WHITE,32,0);
	
	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM8  %7.2fV", ADC_Test[2]);
	//sprintf(buf, "SM8  %7.2fV", test);
	LCD_ShowString(0,210,(uint8_t*)buf,RED,WHITE,32,0);
	
	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM9  %7.2fV", ADC_Test[3]);
	//sprintf(buf, "SM9  %7.2fV", test);
	LCD_ShowString(0,240,(uint8_t*)buf,RED,WHITE,32,0);
	
	test=12.0+(rand()%10)/10.0;	
	sprintf(buf, "SM10  %7.2fV", ADC_Test[5]);
	//sprintf(buf, "SM10 %7.2fV", test);
	LCD_ShowString(0,270,(uint8_t*)buf,RED,WHITE,32,0);

}


void key_press_proc(int8_t id)
{
    //led_rev(LED_0);
	uint8_t buf[8];
	switch(id){
		case 0:
			LCD_ShowString(120,300,"SPWM SET.....",RED,WHITE,16,0);
			SPWM_SET();
			LCD_ShowString(120,300,"SPWM SET OK!",RED,WHITE,16,0);
		break;
		case 1:
			switch(KEY++){
				case 0:
					SIN_Test(0);
					break;
				case 1:
					SIN_Test(1);
					break;
				case 2:
					SIN_Test(2);
					KEY=0;
					break;				
			}
			sprintf(buf, "KEY= %d", KEY);
			LCD_ShowString(10,300,(uint8_t*)buf,RED,WHITE,16,0);
		break;

	}
    APP_DEBUG("key press %d\r\n", id);
}


static uint16_t adc_get_value_array[CHANNEL_NUMBER + 1] = {0};
static int16_t adc_difference_value_array[CHANNEL_NUMBER >> 1] = {0};


void adc_receive_proc(void *pbuf, int len)
{
    static uint32_t last_counter = 0;
    
    if( hal_read_TickCounter() - last_counter > 1000) {
        last_counter = hal_read_TickCounter();
        
        uint16_t *u16pbuf = (uint16_t *)pbuf;
        
        printf("--------------------------------[ADC]--------------------------\r\n");
        
        for(int i=0; i<CHANNEL_NUMBER; i++) {
            adc_get_value_array[i] = No_Max_Min_Filter(u16pbuf, CONV_NUMBER, CHANNEL_NUMBER, i);
            if(i&1) {
                adc_difference_value_array[i >> 1] = (int16_t)adc_get_value_array[i-1] - adc_get_value_array[i];
                float adc_voltage = adc_difference_value_array[i >> 1]*3.3/4096;
                float rcc = (10.0*28)/(10+28);
                float mmc_voltage = adc_voltage / 8.0 / (rcc/(620 + rcc));
                APP_DEBUG("din %02d [ %2d:(%4d) - %2d:(%4d) = %d(%.3f,%.3f) ]\r\n",
                i >> 1, i-1, adc_get_value_array[i-1], i, adc_get_value_array[i], adc_difference_value_array[i >> 1],
                 adc_voltage, mmc_voltage);
				ADC_Test[i/2]=mmc_voltage+1;
            }
        }
        
        printf("--------------------------------[ADC]--------------------------\r\n");
    }
}


int main(void)
{
    data_interface_hal_init();
    soft_timer_init();
	
    LCD_Init();	
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
	//LCD_ShowString(0,0,"Power Working",RED,WHITE,32,0);
	
    soft_timer_create(SOFT_TIMER_LED, 1, 1, led_proc, 200);
	soft_timer_create(MMC_Vlot, 1, 1, MMC_Voltage, 500);
    
    APP_DEBUG("init success %s %s\r\n", __TIME__, __DATE__);
    
    while(1)
    {
        soft_timer_proc();   //timer
        keys_proc(key_press_proc);  //key
        adc_rx_proc(adc_receive_proc);
    }
}

/******************* (C) COPYRIGHT 2018 hxdyxd *****END OF FILE****/
