/* Global Configuration 
 *  By hxdyxd 
 * 2018 07 05 CREAT
*/

#ifndef _TYPE_H
#define _TYPE_H

#include <stdint.h>

/* configuration */

#define SOFT_TIMER_LED  0
#define MMC_Vlot  1


#endif
/******************* (C) COPYRIGHT 2018 hxdyxd *****END OF FILE****/
