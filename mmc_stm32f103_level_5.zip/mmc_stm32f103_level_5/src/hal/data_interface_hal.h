/* 
 *
 *2018 09 21 & hxdyxd
 *
 */


#ifndef __data_interface_hal_H__
#define __data_interface_hal_H__

#include <stdint.h>

#include "leds.h"
#include "keys.h"

#include "adc.h"

//led id
#define LED_0       (0)


/*******************************************************************************
* Function Name  : data_interface_hal_init.
* Description    :Hardware adaptation layer initialization.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void data_interface_hal_init(void);

void SPWM_SET(void);

inline uint32_t hal_read_TickCounter(void);


#endif
